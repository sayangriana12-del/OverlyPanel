package com.example.overlaypanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs
import kotlin.random.Random

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private lateinit var content: FrameLayout
    private var player: MediaPlayer? = null
    private var video: VideoView? = null
    private var score = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs by lazy { getSharedPreferences("panel", Context.MODE_PRIVATE) }
    private val type get() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        buildPanel()
        buildBubble()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("panel", "Panel Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "panel") else Notification.Builder(this))
            .setContentTitle("Panel Overlay aktif")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun bg(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    // ---------- Bubble (tombol melayang, bisa digeser) ----------
    private fun buildBubble() {
        val b = TextView(this).apply {
            text = "▶"; textSize = 20f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = bg(Color.parseColor("#CC1565C0"), 28)
        }
        val lp = WindowManager.LayoutParams(dp(56), dp(56), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(200)
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP ->
                    if (abs(e.rawX - tx) < 10 && abs(e.rawY - ty) < 10) togglePanel(lp)
            }
            true
        }
        bubble = b
        wm.addView(b, lp)
    }

    private fun togglePanel(bubbleLp: WindowManager.LayoutParams) {
        val p = panel ?: return
        if (p.visibility == View.VISIBLE) {
            p.visibility = View.GONE; pauseAll()
        } else {
            val lp = p.layoutParams as WindowManager.LayoutParams
            lp.x = dp(8); lp.y = bubbleLp.y + dp(64)
            wm.updateViewLayout(p, lp)
            p.visibility = View.VISIBLE
        }
    }

    // ---------- Panel menu ----------
    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(Color.parseColor("#F2212121"), 16)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            visibility = View.GONE
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tab(label: String, action: () -> Unit) = tabs.addView(
            Button(this).apply {
                text = label; textSize = 11f; isAllCaps = false
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tab("Musik") { showMusic() }
        tab("Video") { showVideo() }
        tab("Game") { showGame() }
        tab("Tutup") { stopSelf() }
        content = FrameLayout(this)
        p.addView(tabs)
        p.addView(content, LinearLayout.LayoutParams(dp(300), dp(200)))

        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        panel = p
        wm.addView(p, lp)
        showMusic()
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); gravity = Gravity.CENTER
    }

    private fun pauseAll() {
        try { player?.takeIf { it.isPlaying }?.pause() } catch (_: Exception) {}
        video?.pause()
    }

    // ---------- Musik ----------
    private fun showMusic() {
        content.removeAllViews(); video?.pause()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val uriStr = prefs.getString("music", null)
        col.addView(label(if (uriStr == null) "Pilih file musik di aplikasi utama" else "Pemutar Musik"))
        val play = Button(this).apply { text = if (player?.isPlaying == true) "Jeda" else "Putar" }
        play.setOnClickListener {
            if (uriStr == null) { toast("Belum ada file musik"); return@setOnClickListener }
            try {
                if (player == null) player = MediaPlayer().apply {
                    setDataSource(this@OverlayService, Uri.parse(uriStr)); prepare()
                    setOnCompletionListener { play.text = "Putar" }
                }
                val m = player!!
                if (m.isPlaying) { m.pause(); play.text = "Putar" } else { m.start(); play.text = "Jeda" }
            } catch (e: Exception) { toast("Gagal memutar: ${e.message}") }
        }
        col.addView(play)
        content.addView(col, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- Video ----------
    private fun showVideo() {
        content.removeAllViews(); pauseAll()
        val uriStr = prefs.getString("video", null)
        if (uriStr == null) { content.addView(label("Pilih file video di aplikasi utama")); return }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val v = VideoView(this).also { video = it; it.setVideoURI(Uri.parse(uriStr)) }
        col.addView(v, LinearLayout.LayoutParams(-1, dp(150)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "Putar"; setOnClickListener { v.start() } }, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(Button(this).apply { text = "Jeda"; setOnClickListener { v.pause() } }, LinearLayout.LayoutParams(0, dp(44), 1f))
        col.addView(row)
        content.addView(col, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- Game: ketuk target ----------
    private fun showGame() {
        content.removeAllViews(); pauseAll(); score = 0
        val scoreTv = label("Skor: 0").apply { textSize = 16f }
        val target = TextView(this).apply { text = "🎯"; textSize = 28f }
        val area = FrameLayout(this)
        fun move() {
            val lp = FrameLayout.LayoutParams(-2, -2)
            lp.leftMargin = Random.nextInt(0, dp(240)); lp.topMargin = Random.nextInt(dp(24), dp(140))
            target.layoutParams = lp
        }
        target.setOnClickListener { score++; scoreTv.text = "Skor: $score"; move() }
        area.addView(scoreTv, FrameLayout.LayoutParams(-1, -2))
        area.addView(target)
        move()
        content.addView(area, FrameLayout.LayoutParams(-1, -1))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        player?.release(); player = null
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
