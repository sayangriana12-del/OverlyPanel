package com.example.overlaypanel

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("panel", Context.MODE_PRIVATE) }
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply { text = "Panel Overlay"; textSize = 24f })
        info = TextView(this).apply { setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(info)
        fun btn(label: String, action: () -> Unit) =
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })

        btn("1. Izinkan tampil di atas aplikasi lain") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else toast("Izin sudah aktif")
        }
        btn("2. Pilih file musik") { pick("music", "audio/*", 1) }
        btn("3. Pilih file video") { pick("video", "video/*", 2) }
        btn("4. Mulai panel") { startPanel() }
        btn("Hentikan panel") { stopService(Intent(this, OverlayService::class.java)) }
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        refresh()
    }

    private fun pick(key: String, mime: String, code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(i, code)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        prefs.edit().putString(if (req == 1) "music" else "video", uri.toString()).apply()
        refresh()
    }

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) { toast("Aktifkan izin overlay dulu"); return }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        moveTaskToBack(true)
    }

    private fun refresh() {
        info.text = "Musik: " + (if (prefs.getString("music", null) != null) "sudah dipilih" else "belum dipilih") +
            "\nVideo: " + (if (prefs.getString("video", null) != null) "sudah dipilih" else "belum dipilih")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
